package homework1;

public class Euclidian_distance {

	public static void main(String[] args) {;
		double x1 = 10;
		double y1 = 17;
		double x2 = 12;
		double y2 = 6;
		System.out.println("the two points are point 1, which has the cooridinates (10, 17), and point 2, which has the cooridinates (12, 6)");
		double result1 = Math.sqrt((Math.pow(x1-x2,2)+Math.pow(y1-y2,2)));
		/* the distance between the two points is the square root of the sum of the
		 * squared difference between the respective x and y values */
	System.out.println(result1);
	System.out.println("is the distance between the two points");
	}}

