package homework1;

public class Polyline_Polygon {;
	public static void main(String[] args) {;
		double x11 = 3;
		double y11 = 4;
		double x12 = 7;
		double y12 = 8;
		double x13 = 10;
		double y13 = 2;
		System.out.println("The polyline consists of three cooridinates: (3, 4), (7, 8), and (10, 2)");
		double x21 = 2;
		double y21 = 17;
		double x22 = 6;
		double y22 = 18;
		double x23 = 9;
		double y23 = 16;
		double x24 = x21;
		double y24 = y21;
		System.out.println("The polygon consists of four points and three unique points: (2, 17), (6, 18), and (9, 16)");
		double distance1 = Math.sqrt((Math.pow(x11-x21, 2)+Math.pow(y11-y21, 2)));
		double distance2 = Math.sqrt((Math.pow(x11-x22, 2)+Math.pow(y11-y22, 2)));
		double distance3 = Math.sqrt((Math.pow(x11-x23, 2)+Math.pow(y11-y23, 2)));
		double distance4 = Math.sqrt((Math.pow(x12-x21, 2)+Math.pow(y12-y21, 2)));
		double distance5 = Math.sqrt((Math.pow(x12-x22, 2)+Math.pow(y12-y22, 2)));
		double distance6 = Math.sqrt((Math.pow(x12-x23, 2)+Math.pow(y12-y23, 2)));
		double distance7 = Math.sqrt((Math.pow(x13-x21, 2)+Math.pow(y13-y21, 2)));
		double distance8 = Math.sqrt((Math.pow(x13-x22, 2)+Math.pow(y13-y22, 2)));
		double distance9 = Math.sqrt((Math.pow(x13-x23, 2)+Math.pow(y13-y23, 2)));
		/* there are nine different distances between the polygon and polyline's three
		 * respective unique points */
		double mindistance1 = (Math.min(distance1 , distance2));
		double mindistance2 = (Math.min(distance3 , distance4));
		double mindistance3 = (Math.min(distance5 , distance6));
		double mindistance4 = (Math.min(distance7 , distance8));
		double mindistance5 = (Math.min(distance9 , mindistance1));
		double mindistance6 = (Math.min(mindistance2 , mindistance3));
		double mindistance7 = (Math.min(mindistance4,  mindistance5));
		double mindistance = (Math.min(mindistance6,  mindistance7));
		System.out.println(mindistance);
		/* find out which of the nine different distances between different points is the minimum */
		System.out.println("is the minimum distance between the polygon and the polyline");

}}